package com.forescout.challenge;

import java.net.Inet4Address;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

public class Network {
  private final Set<Host> hosts = new HashSet<>();

  public Host getHostByIp(Inet4Address inet4Address) {
    return hosts.stream().filter(h -> h.getAddress().equals(inet4Address)).findFirst().orElse(null);
  }

  public Host getHostByName(String hostName) {
    return hosts.stream().filter(h -> h.getHostName().equals(hostName)).findFirst().orElse(null);
  }

  public boolean addHost(Host host) {
    Objects.requireNonNull(host);
    if (getHostByIp(host.getAddress()) != null) {
      throw new IllegalArgumentException("A host with the same ip address already exists");
    }
    if (getHostByName(host.getHostName()) != null) {
      throw new IllegalArgumentException("A host with the same name already exists");
    }
    return hosts.add(host);
  }

  public boolean removeHost(Host host) {
    return hosts.remove(Objects.requireNonNull(host));
  }

  public boolean removeHostByIp(Inet4Address inet4Address) {
    Host host = getHostByIp(inet4Address);
    if (host != null) {
      return removeHost(host);
    }
    return false;
  }

  public boolean removeHostByName(String hostName) {
    Host host = getHostByName(hostName);
    if (host != null) {
      return removeHost(host);
    }
    return false;
  }

  public int hostCount() {
    return hosts.size();
  }
}
