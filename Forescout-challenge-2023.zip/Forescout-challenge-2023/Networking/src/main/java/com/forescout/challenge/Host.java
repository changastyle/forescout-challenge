package com.forescout.challenge;

import java.net.Inet4Address;
import java.util.Objects;

public class Host {

  private Inet4Address address;
  private String hostName;

  public Host(Inet4Address address, String hostName) {
    setAddress(address);
    setHostName(hostName);
  }

  public Inet4Address getAddress() {
    return address;
  }

  public void setAddress(Inet4Address address) {
    this.address = Objects.requireNonNull(address);
  }

  public String getHostName() {
    return hostName;
  }

  public void setHostName(String hostName) {
    this.hostName = Objects.requireNonNull(hostName);
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof Host)) {
      return false;
    }
    Host host = (Host) o;
    return address.equals(host.address) && hostName.equalsIgnoreCase(host.hostName);
  }

  @Override
  public int hashCode() {
    return Objects.hash(address, hostName);
  }
}
