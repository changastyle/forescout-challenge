package com.forescout.challenge;

public class Main {

  public static void main(String[] args) {
    System.out.println("Forescout challenge. Run the test with \"mvn test\".");
  }
}